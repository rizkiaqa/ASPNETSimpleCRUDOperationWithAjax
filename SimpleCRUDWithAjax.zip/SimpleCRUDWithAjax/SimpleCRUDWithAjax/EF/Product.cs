﻿using System;
using System.Collections.Generic;

namespace SimpleCRUDWithAjax.EF;

public partial class Product
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public int Price { get; set; }

    public bool Active { get; set; }

    public DateTime ExpiredDate { get; set; }
}
